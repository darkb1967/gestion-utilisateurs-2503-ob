/* requete ecf mardi 14 octobre */
USE db_architecte;

/* requete 1 */
SELECT client_ref, client_nom, client_telephone
FROM clients
WHERE client_telephone LIKE '%04%';

/* requete 2*/
SELECT client_ref, client_nom, type_clients.type_client_libelle
FROM clients
INNER JOIN type_clients ON type_clients.type_client_id = clients.type_client_id
WHERE type_clients.type_client_libelle = 'Particulier';

/* requete 3 */
SELECT client_ref, client_nom, type_clients.type_client_libelle
FROM clients
INNER JOIN type_clients ON type_clients.type_client_id = clients.type_client_id
WHERE type_clients.type_client_libelle <> 'Particulier';

/* requete 4 */
SELECT projet_date_fin_prevue, projet_date_fin_effective, clients.client_nom
FROM projets
INNER JOIN clients ON clients.client_ref = projets.client_ref
WHERE projet_date_fin_prevue < projet_date_fin_effective;

/* requete 5 */
SELECT projet_date_depot, projet_date_fin_prevue, projet_superficie_totale, projet_superficie_batie, projet_prix, clients.client_nom, employes.emp_nom
FROM projets
INNER JOIN clients ON clients.client_ref = projets.client_ref
INNER JOIN employes ON employes.emp_matricule = projets.emp_matricule
where employes.fonction_id=1;
-- (select employes.fonction_id FROM employes WHERE employes.fonction_id =1);

/* requete 6 */
SELECT projet_date_depot, projet_date_fin_prevue, projet_superficie_totale, projet_superficie_batie, projet_prix, clients.client_nom, employes.emp_nom
FROM projets
INNER JOIN clients ON clients.client_ref = projets.client_ref
INNER JOIN employes ON employes.emp_matricule = projets.emp_matricule
where employes.fonction_id <> 1;

/* requete 7 */
SELECT type_projet_libelle, (select COUNT(type_projet_libelle) FROM type_projets) AS nbprojets, projets.projet_prix
FROM type_projets
INNER JOIN projets ON projets.type_projet_id = type_projets.type_projet_id
order BY type_projet_libelle;

SELECT type_projet_libelle, count(type_projet_libelle)
FROM type_projets
group BY type_projet_libelle;

/* requete 8 */
SELECT type_travaux_libelle, max(projets.projet_superficie_totale) AS superficie
FROM type_travaux
INNER JOIN projets ON projets.type_projet_id = type_travaux.type_travaux_id
group BY type_travaux_libelle;

/* requete 9 */
SELECT projet_date_depot, projet_date_fin_prevue, projet_prix, clients.client_nom, clients.client_telephone, adresses.adresse_num_voie, adresses.adresse_voie,
 adresses.adresse_code_postal, adresses.adresse_ville, type_travaux.type_travaux_libelle, type_projets.type_projet_libelle
FROM projets
INNER JOIN clients ON clients.client_ref = projets.client_ref
INNER JOIN adresses ON adresses.adresse_id = projets.adresse_id
INNER JOIN type_travaux ON type_travaux.type_travaux_id = projets.type_travaux_id
INNER JOIN type_projets ON type_projets.type_projet_id = projets.type_projet_id

/* requete 10 */
SELECT client_nom, adresses.adresse_ville
FROM clients
INNER JOIN adresses ON adresses.adresse_id = clients.adresse_id
WHERE client_nom LIKE adresses.adresse_ville;
